//==============================================================================
// Project      : RISCV64 Processor
// Module       : PC Plus-4 Generator Testbench
// File         : tb_pc_plus4_gen.sv
//
// Description  :
//   Self-checking testbench for the PC Plus-4 Generator.
//
//   Test Cases:
//     1. Reset Vector
//     2. Small Address
//     3. Aligned Address
//     4. Large Address
//     5. Maximum Address (Overflow)
//
//------------------------------------------------------------------------------
// Author       : Siddhartha Chinta
// Organization : Personal Learning Project
//
// Target ISA   : RV64I
// Language     : SystemVerilog
//==============================================================================

`timescale 1ns/1ps

module tb_pc_plus4_gen;

    import riscv_pkg::*;

    //==========================================================================
    // DUT Signals
    //==========================================================================

    xlen_t pc_i;
    xlen_t pc_plus4_o;

    //==========================================================================
    // Statistics
    //==========================================================================

    integer total_tests;
    integer passed_tests;
    integer failed_tests;

    //==========================================================================
    // DUT
    //==========================================================================

    pc_plus4_gen dut (

        .pc_i       (pc_i),
        .pc_plus4_o (pc_plus4_o)

    );

    //==========================================================================
    // Waveform Dump
    //==========================================================================

    initial begin
        $dumpfile("../waves/tb_pc_plus4_gen.vcd");
        $dumpvars(0, tb_pc_plus4_gen);
    end

    //==========================================================================
    // Self-Checking Task
    //==========================================================================

    task automatic check_output(

        input string test_name,
        input xlen_t expected

    );

    begin

        total_tests++;

        if (pc_plus4_o === expected) begin

            passed_tests++;

            $display("PASS : %-25s Expected=%h Got=%h",
                     test_name, expected, pc_plus4_o);

        end
        else begin

            failed_tests++;

            $display("FAIL : %-25s Expected=%h Got=%h",
                     test_name, expected, pc_plus4_o);

        end

    end

    endtask

    //==========================================================================
    // Test Sequence
    //==========================================================================

    initial begin

        total_tests  = 0;
        passed_tests = 0;
        failed_tests = 0;

        $display("");
        $display("==================================================");
        $display("        PC PLUS-4 GENERATOR VERIFICATION");
        $display("==================================================");

        //----------------------------------------------------------------------
        // Test 1 : Reset Vector
        //----------------------------------------------------------------------

        pc_i = 64'h0000_0000_0000_0000;
        #10;
        check_output("Reset Vector", 64'h0000_0000_0000_0004);

        //----------------------------------------------------------------------
        // Test 2 : Small Address
        //----------------------------------------------------------------------

        pc_i = 64'h0000_0000_0000_0010;
        #10;
        check_output("Small Address", 64'h0000_0000_0000_0014);

        //----------------------------------------------------------------------
        // Test 3 : Aligned Address
        //----------------------------------------------------------------------

        pc_i = 64'h0000_0000_0000_0100;
        #10;
        check_output("Aligned Address", 64'h0000_0000_0000_0104);

        //----------------------------------------------------------------------
        // Test 4 : Large Address
        //----------------------------------------------------------------------

        pc_i = 64'h1234_5678_9ABC_DEF0;
        #10;
        check_output("Large Address", 64'h1234_5678_9ABC_DEF4);

        //----------------------------------------------------------------------
        // Test 5 : Overflow
        //----------------------------------------------------------------------

        pc_i = 64'hFFFF_FFFF_FFFF_FFFC;
        #10;
        check_output("Address Overflow", 64'h0000_0000_0000_0000);

        //----------------------------------------------------------------------
        // Summary
        //----------------------------------------------------------------------

        $display("");
        $display("==================================================");
        $display("                 TEST SUMMARY");
        $display("==================================================");

        $display("Total Tests  : %0d", total_tests);
        $display("Passed Tests : %0d", passed_tests);
        $display("Failed Tests : %0d", failed_tests);

        if (failed_tests == 0) begin
            $display("");
            $display("***********************************************");
            $display("*                                             *");
            $display("*    ALL PC PLUS-4 TESTS PASSED               *");
            $display("*                                             *");
            $display("***********************************************");
        end
        else begin
            $display("");
            $display("***********************************************");
            $display("*                                             *");
            $display("*     PC PLUS-4 TESTS FAILED                  *");
            $display("*                                             *");
            $display("***********************************************");
        end

        $finish;

    end

endmodule : tb_pc_plus4_gen
