//==============================================================================
// Project      : RISCV64 Processor
// Module       : PC Plus-4 Generator
// File         : pc_plus4_gen.sv
//
// Description  :
//   Computes the sequential Program Counter value (PC + 4) for RV64I
//   instruction execution.
//
//   This module is purely combinational and is used for:
//     - Sequential instruction execution
//     - JAL/JALR write-back (rd = PC + 4)
//
//------------------------------------------------------------------------------
// Author       : Siddhartha Chinta
// Organization : Personal Learning Project
//
// Target ISA   : RV64I
// Language     : SystemVerilog
//==============================================================================

`timescale 1ns/1ps

module pc_plus4_gen
    import riscv_pkg::*;
(

    //--------------------------------------------------------------------------
    // Inputs
    //--------------------------------------------------------------------------

    input  xlen_t pc_i,

    //--------------------------------------------------------------------------
    // Outputs
    //--------------------------------------------------------------------------

    output xlen_t pc_plus4_o

);

    //==========================================================================
    // PC + 4 Computation
    //==========================================================================

    assign pc_plus4_o = pc_i + xlen_t'(64'd4);

endmodule : pc_plus4_gen
